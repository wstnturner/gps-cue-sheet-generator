package cis522;

class PathFinder {
    public static void main(String[] args) {
        System.out.println("Hello PathFinder!!!!"); // Display the string.
    }
}
